from django.core.mail import send_mail
from django.conf import settings
import os
import django

# Set up Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'DjangoProject4.settings')
django.setup()

def test_email():
    print("Testing email functionality...")

    recipient = 'your_real_email@gmail.com'  # Bu yerga o'zingizning emailingizni yozing

    subject = 'Test Email from Django (SMTP)'
    message = """
    Salom! Bu Django ilovangizdan yuborilgan test xatidir.

    Agar siz bu xatni olgan bo‘lsangiz, SMTP sozlamalari to‘g‘ri ishlayapti.

    Hurmat bilan,
    Django App
    """

    print(f"EMAIL_BACKEND: {settings.EMAIL_BACKEND}")
    print(f"EMAIL_HOST: {settings.EMAIL_HOST}")
    print(f"EMAIL_PORT: {settings.EMAIL_PORT}")
    print(f"EMAIL_USE_TLS: {settings.EMAIL_USE_TLS}")
    print(f"EMAIL_HOST_USER: {settings.EMAIL_HOST_USER}")
    print(f"DEFAULT_FROM_EMAIL: {settings.DEFAULT_FROM_EMAIL}")

    try:
        print(f"Sending test email to {recipient}...")
        result = send_mail(
            subject,
            message,
            settings.DEFAULT_FROM_EMAIL,
            [recipient],
            fail_silently=False,
        )
        print(f"✅ Email yuborildi. Natija: {result}")
    except Exception as e:
        print(f"❌ Xatolik: {e}")

if __name__ == "__main__":
    test_email()
