from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.template.defaulttags import csrf_token
from django.utils.translation import gettext_lazy as _
from .forms import CustomUserCreationForm, CustomAuthenticationForm, UserProfileForm, UserForm
from django.db import transaction
from django.http import JsonResponse
from django.core.mail import send_mail
from django.conf import settings

# Create your views here.
def index(request):
    """
    View function for the home page of the school website.
    """
    return render(request, 'index.html')

def register_view(request):
    """
    View function for user registration.
    """
    if request.user.is_authenticated:
        return redirect('index')

    # Check if the user was redirected from a course registration page
    next_url = request.GET.get('next', '')
    if 'biz_bilan_boglan' in next_url:
        messages.info(request, _("Kursga ro'yxatdan o'tish uchun avval ro'yxatdan o'tishingiz kerak"))

    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, _("Ro'yxatdan muvaffaqiyatli o'tdingiz!"))

            # Redirect to the next URL if it exists
            next_url = request.POST.get('next', '')
            if next_url:
                return redirect(next_url)
            return redirect('index')
    else:
        form = CustomUserCreationForm()

    return render(request, 'register.html', {'form': form})

def login_view(request):
    """
    View function for user login.
    """
    if request.user.is_authenticated:
        return redirect('index')

    # Check if the user was redirected from a course registration page
    next_url = request.GET.get('next', '')
    if 'biz_bilan_boglan' in next_url:
        messages.info(request, _("Kursga ro'yxatdan o'tish uchun avval tizimga kirishingiz kerak"))

    if request.method == 'POST':
        form = CustomAuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.success(request, _("Muvaffaqiyatli kirdingiz!"))

                # Redirect to the next URL if it exists
                next_url = request.POST.get('next', '')
                if next_url:
                    return redirect(next_url)
                return redirect('index')
    else:
        form = CustomAuthenticationForm()

    return render(request, 'login.html', {'form': form, 'next': next_url})

def logout_view(request):
    """
    View function for user logout.
    """
    logout(request)
    messages.success(request, _("Muvaffaqiyatli chiqdingiz!"))
    return redirect('index')

@login_required
def profile_view(request):
    """
    View function for viewing and editing user profile.
    """
    if request.method == 'POST':
        user_form = UserForm(request.POST, instance=request.user)
        profile_form = UserProfileForm(request.POST, request.FILES, instance=request.user.profile)

        if user_form.is_valid() and profile_form.is_valid():
            with transaction.atomic():
                user_form.save()
                profile_form.save()
            messages.success(request, _("Profil muvaffaqiyatli yangilandi!"))
            return redirect('profile')
    else:
        user_form = UserForm(instance=request.user)
        profile_form = UserProfileForm(instance=request.user.profile)

    return render(request, 'profile.html', {
        'user_form': user_form,
        'profile_form': profile_form
    })


@login_required
def course_registration_view(request):
    """
    View function for course registration.
    This view requires authentication.
    """
    if request.method == 'POST':
        # Process the form data
        name = request.POST.get('name')
        phone = request.POST.get('phone')
        course = request.POST.get('course', '')
        message = request.POST.get('message', '')

        # Get the user's email address
        user_email = request.user.email

        # Log the user's email for debugging
        print("User email:", user_email)

        # Check if email is valid
        if not user_email:
            return JsonResponse({
                'status': 'error', 
                'message': _('Email address is missing. Please update your profile with a valid email.')
            })

        # Prepare email content
        subject = _('Kurs uchun ro\'yxatdan o\'tish')
        email_message = _("""
Hurmatli {name},

Siz quyidagi ma'lumotlar bilan kursga ro'yxatdan o'tdingiz:

Telefon raqam: {phone}
Kurs: {course}
Qo'shimcha ma'lumot: {message}

Tez orada operatorlarimiz siz bilan bog'lanishadi.

Hurmat bilan,
QORAKO'L EVOLUTION SCHOOL
        """).format(name=name, phone=phone, course=course, message=message)

        # Send email to the user with error handling
        try:
            result = send_mail(
                subject,
                email_message,
                settings.EMAIL_HOST_USER,
                [user_email],
                fail_silently=False,
            )
            print("Send mail result:", result)

            if result == 0:
                print("Email failed to send but no exception was raised")
                return JsonResponse({
                    'status': 'error', 
                    'message': _('Failed to send email. Please try again later.')
                })

        except Exception as e:
            print("Email error:", e)
            return JsonResponse({
                'status': 'error', 
                'message': _('An error occurred while sending the email. Please try again later.')
            })

        # Here you would typically save this data to the database
        # For now, we'll just return a success response

        return JsonResponse({'status': 'success', 'message': _('Kurs uchun ro\'yxatdan o\'tish muvaffaqiyatli amalga oshirildi! Ma\'lumotlar elektron pochtangizga yuborildi.')})

    # If it's not a POST request, redirect to the home page
    return redirect('index')
