from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.models import User
from .models import UserProfile
from django.utils.translation import gettext_lazy as _

class CustomUserCreationForm(UserCreationForm):
    email = forms.EmailField(required=True)
    first_name = forms.CharField(max_length=30, required=True)
    last_name = forms.CharField(max_length=30, required=True)
    
    class Meta:
        model = User
        fields = ('username', 'email', 'first_name', 'last_name', 'password1', 'password2')
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Add placeholders and classes to form fields
        self.fields['username'].widget.attrs.update({'class': 'form-control', 'placeholder': _('Username')})
        self.fields['email'].widget.attrs.update({'class': 'form-control', 'placeholder': _('Email')})
        self.fields['first_name'].widget.attrs.update({'class': 'form-control', 'placeholder': _('First Name')})
        self.fields['last_name'].widget.attrs.update({'class': 'form-control', 'placeholder': _('Last Name')})
        self.fields['password1'].widget.attrs.update({'class': 'form-control', 'placeholder': _('Password')})
        self.fields['password2'].widget.attrs.update({'class': 'form-control', 'placeholder': _('Confirm Password')})

class CustomAuthenticationForm(AuthenticationForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Add placeholders and classes to form fields
        self.fields['username'].widget.attrs.update({'class': 'form-control', 'placeholder': _('Username')})
        self.fields['password'].widget.attrs.update({'class': 'form-control', 'placeholder': _('Password')})

class UserProfileForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = ('phone_number', 'address', 'bio', 'profile_picture')
        
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Add placeholders and classes to form fields
        self.fields['phone_number'].widget.attrs.update({'class': 'form-control', 'placeholder': _('Phone Number')})
        self.fields['address'].widget.attrs.update({'class': 'form-control', 'placeholder': _('Address')})
        self.fields['bio'].widget.attrs.update({'class': 'form-control', 'placeholder': _('Bio')})
        self.fields['profile_picture'].widget.attrs.update({'class': 'form-control'})

class UserForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ('first_name', 'last_name', 'email')
        
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Add placeholders and classes to form fields
        self.fields['first_name'].widget.attrs.update({'class': 'form-control', 'placeholder': _('First Name')})
        self.fields['last_name'].widget.attrs.update({'class': 'form-control', 'placeholder': _('Last Name')})
        self.fields['email'].widget.attrs.update({'class': 'form-control', 'placeholder': _('Email')})