/** @format */

// Navbar menyuni yopish
document.addEventListener('DOMContentLoaded', function () {
  const navLinks = document.querySelectorAll('.navbar-nav .nav-link');
  const navbarToggler = document.querySelector('.navbar-toggler');
  const navbarCollapse = document.querySelector('.navbar-collapse');

  navLinks.forEach((link) => {
    link.addEventListener('click', () => {
      if (navbarCollapse.classList.contains('show')) {
        navbarToggler.click(); // Menyuni yopish
      }
    });
  });
});

// Til almashish formalarini boshqarish
const langForms = document.querySelectorAll('[id^="lang-form-"]');
langForms.forEach((form) => {
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    this.submit();
  });
});

// Statistikani animatsiya qilish
const statNumbers = document.querySelectorAll('.stat-number');
const animateStats = () => {
  statNumbers.forEach((stat) => {
    const target = parseInt(stat.getAttribute('data-count'));
    let count = 0;
    const increment = target / 100;
    const updateCount = () => {
      if (count < target) {
        count += increment;
        stat.textContent = Math.ceil(count);
        requestAnimationFrame(updateCount);
      } else {
        stat.textContent = target;
      }
    };
    updateCount();
  });
};

// Statistikani faqat ko‘rinadigan bo‘lsa ishga tushirish
const statsSection = document.querySelector('.stats-container');
const observer = new IntersectionObserver(
  (entries) => {
    if (entries[0].isIntersecting) {
      animateStats();
      observer.unobserve(statsSection);
    }
  },
  { threshold: 0.5 }
);
observer.observe(statsSection);

// Filial tablarini boshqarish
const filialTabs = document.querySelectorAll('.filial-tab');
const branchInfoBoxes = document.querySelectorAll('.branch-info-box');

filialTabs.forEach((tab) => {
  tab.addEventListener('click', () => {
    filialTabs.forEach((t) => t.classList.remove('active'));
    tab.classList.add('active');

    const branch = tab.getAttribute('data-branch');
    branchInfoBoxes.forEach((box) => {
      box.style.display = box.id === `${branch}-info` ? 'block' : 'none';
    });
  });
});

// Slider funksiyasi
const sliderContainer = document.querySelector('.slider-container');
const prevBtn = document.querySelector('.prev-btn');
const nextBtn = document.querySelector('.next-btn');
let currentIndex = 0;

const updateSlider = () => {
  const itemWidth = sliderContainer.children[0].offsetWidth + 20; // Margin hisobga olinadi
  sliderContainer.style.transform = `translateX(-${
    currentIndex * itemWidth
  }px)`;
};

nextBtn.addEventListener('click', () => {
  if (currentIndex < sliderContainer.children.length - 1) {
    currentIndex++;
    updateSlider();
  }
});

prevBtn.addEventListener('click', () => {
  if (currentIndex > 0) {
    currentIndex--;
    updateSlider();
  }
});

window.addEventListener('resize', updateSlider);
/** @format */

document.addEventListener('DOMContentLoaded', () => {
  // CSRF tokenini olish
  const getCsrfToken = () => {
    const cookie = document.cookie
      .split(';')
      .find((c) => c.trim().startsWith('csrftoken='));
    return cookie ? cookie.split('=')[1] : '';
  };

  // Til almashish formalarini boshqarish
  const langForms = document.querySelectorAll('form[id^="lang-form-"]');
  langForms.forEach((form) => {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const formData = new FormData(form);
      fetch('/i18n/setlang/', {
        method: 'POST',
        body: formData,
        headers: {
          'X-CSRFToken': getCsrfToken(),
          'X-Requested-With': 'XMLHttpRequest',
        },
        credentials: 'same-origin',
      })
        .then((response) => {
          if (response.ok) {
            const nextUrl = formData.get('next') || window.location.pathname;
            window.location.href = nextUrl;
          } else {
            console.error("Til o'zgartirishda xato:", response.status);
            alert(
              "Til o'zgartirishda xato yuz berdi. Iltimos, qayta urinib ko'ring."
            );
          }
        })
        .catch((error) => {
          console.error('Til formasini yuborishda xato:', error);
          alert(
            "Server bilan bog'lanishda xato. Iltimos, qayta urinib ko'ring."
          );
        });
    });
  });
  document.addEventListener('DOMContentLoaded', () => {
    // Menyu elementiga bosilganda menyuni yopish
    const navLinks = document.querySelectorAll('.nav-link');
    const navbarToggler = document.querySelector('.navbar-toggler');
    const navbarCollapse = document.querySelector('.navbar-collapse');

    navLinks.forEach((link) => {
      link.addEventListener('click', () => {
        if (navbarCollapse.classList.contains('show')) {
          navbarToggler.click(); // Hamburger menyuni yopish
        }
      });
    });

    // Til almashish formalarini boshqarish
    const langForms = document.querySelectorAll('form[id^="lang-form-"]');
    langForms.forEach((form) => {
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        const formData = new FormData(form);
        fetch('/i18n/setlang/', {
          method: 'POST',
          body: formData,
          headers: {
            'X-CSRFToken': getCsrfToken(),
            'X-Requested-With': 'XMLHttpRequest',
          },
          credentials: 'same-origin',
        })
          .then((response) => {
            if (response.ok) {
              const nextUrl = formData.get('next') || window.location.pathname;
              window.location.href = nextUrl;
            } else {
              console.error("Til o'zgartirishda xato:", response.status);
              alert(
                "Til o'zgartirishda xato yuz berdi. Iltimos, qayta urinib ko'ring."
              );
            }
          })
          .catch((error) => {
            console.error('Til formasini yuborishda xato:', error);
            alert(
              "Server bilan bog'lanishda xato. Iltimos, qayta urinib ko'ring."
            );
          });
      });
    });

    // CSRF tokenini olish
    function getCsrfToken() {
      const cookie = document.cookie
        .split(';')
        .find((c) => c.trim().startsWith('csrftoken='));
      return cookie ? cookie.split('=')[1] : '';
    }
  });
  // Filiallar o'rtasida almashish
  const branches = ['qorakol', 'buxoro', 'gijduvon', 'kogon', 'olot'];
  const filialTabs = document.querySelectorAll('.filial-tab');

  function showBranch(branchId) {
    // Barcha iframe va ma'lumot oynalarini yashirish
    branches.forEach((id) => {
      const iframe = document.getElementById(`iframe-${id}`);
      const infoBox = document.getElementById(`${id}-info`);
      const tab = document.querySelector(`.filial-tab[data-branch="${id}"]`);
      if (iframe) iframe.style.display = id === branchId ? 'block' : 'none';
      if (infoBox) infoBox.style.display = id === branchId ? 'block' : 'none';
      if (tab) tab.classList.toggle('active', id === branchId);
    });
  }

  // Filial tugmalari uchun click hodisasi
  document.addEventListener('DOMContentLoaded', function () {
    const filialTabs = document.querySelectorAll('.filial-tab');
    const branchInfoBoxes = document.querySelectorAll('.branch-info-box');
    const iframes = document.querySelectorAll('.map-container iframe');

    filialTabs.forEach((tab) => {
      tab.addEventListener('click', () => {
        // Barcha tablardan active sinfini olib tashlash
        filialTabs.forEach((t) => t.classList.remove('active'));
        tab.classList.add('active');

        // Tanlangan filialga mos ma'lumot va iframe'ni ko'rsatish
        const branch = tab.getAttribute('data-branch');
        branchInfoBoxes.forEach((box) => {
          box.style.display = box.id === `${branch}-info` ? 'block' : 'none';
        });
        iframes.forEach((iframe) => {
          iframe.style.display =
            iframe.id === `iframe-${branch}` ? 'block' : 'none';
        });
      });
    });

    // Oldingi skriptdagi boshqa funksiyalar (masalan, navbar, statistika animatsiyasi) shu yerda qoladi
  });
  filialTabs.forEach((tab) => {
    tab.addEventListener('click', () => {
      const branchId = tab.getAttribute('data-branch');
      showBranch(branchId);
    });
  });

  // Default filialni ko'rsatish
  showBranch('qorakol');

  const menuLinks = document.querySelectorAll('nav ul li a');
  menuLinks.forEach((link) => {
    link.addEventListener('click', () => {
      navMenu.classList.remove('active');
      if (toggleIcon) {
        toggleIcon.classList.add('fa-bars');
        toggleIcon.classList.remove('fa-times');
      }
    });
  });
  // Sticky header
  const header = document.querySelector('header');
  window.addEventListener('scroll', () => {
    header.classList.toggle('sticky', window.scrollY > 50);
  });

  // Price tabs
  const tabButtons = document.querySelectorAll('.tab-btn');
  const tabPanes = document.querySelectorAll('.tab-pane');
  tabButtons.forEach((button) => {
    button.addEventListener('click', () => {
      const tabId = button.getAttribute('data-tab');
      tabButtons.forEach((btn) => btn.classList.remove('active'));
      button.classList.add('active');
      tabPanes.forEach((pane) => pane.classList.remove('active'));
      document.getElementById(tabId).classList.add('active');
    });
  });

  // Gallery filter
  const filterButtons = document.querySelectorAll('.filter-btn');
  const galleryItems = document.querySelectorAll('.gallery-item');
  filterButtons.forEach((button) => {
    button.addEventListener('click', () => {
      const filterValue = button.getAttribute('data-filter');
      filterButtons.forEach((btn) => btn.classList.remove('active'));
      button.classList.add('active');
      galleryItems.forEach((item) => {
        item.style.display =
          filterValue === 'all' || item.classList.contains(filterValue)
            ? 'block'
            : 'none';
      });
    });
  });

  // Gallery lightbox
  const galleryZoomLinks = document.querySelectorAll('.gallery-zoom');
  const lightbox = document.getElementById('galleryLightbox');
  const lightboxImage = document.getElementById('galleryLightboxImage');
  const lightboxCaption = document.getElementById('galleryLightboxCaption');
  const closeLightbox = document.querySelector('.close-lightbox');
  let currentImageIndex = 0;
  const galleryImages = Array.from(galleryZoomLinks).map((link) => ({
    url: link.getAttribute('href'),
    caption: link.closest('.gallery-item').querySelector('.overlay-content h3')
      .textContent,
  }));

  galleryZoomLinks.forEach((link, index) => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      currentImageIndex = index;
      lightboxImage.src = galleryImages[index].url;
      lightboxCaption.textContent = galleryImages[index].caption;
      lightbox.style.display = 'block';
      document.body.style.overflow = 'hidden';
    });
  });

  closeLightbox?.addEventListener('click', () => {
    lightbox.style.display = 'none';
    document.body.style.overflow = 'auto';
  });

  // Lightbox navigation
  window.nextImage = () => {
    currentImageIndex = (currentImageIndex + 1) % galleryImages.length;
    lightboxImage.src = galleryImages[currentImageIndex].url;
    lightboxCaption.textContent = galleryImages[currentImageIndex].caption;
  };

  window.previousImage = () => {
    currentImageIndex =
      (currentImageIndex - 1 + galleryImages.length) % galleryImages.length;
    lightboxImage.src = galleryImages[currentImageIndex].url;
    lightboxCaption.textContent = galleryImages[currentImageIndex].caption;
  };

  // Teachers slider
  const sliderContainer = document.querySelector('.slider-container');
  const prevBtn = document.querySelector('.prev-btn');
  const nextBtn = document.querySelector('.next-btn');
  if (sliderContainer && prevBtn && nextBtn) {
    const slideWidth = 310; // Har bir teacher-card o'lchami
    prevBtn.addEventListener('click', () => {
      sliderContainer.scrollBy({ left: -slideWidth, behavior: 'smooth' });
    });
    nextBtn.addEventListener('click', () => {
      sliderContainer.scrollBy({ left: slideWidth, behavior: 'smooth' });
    });
  }

  // Kontakt formasi
  const contactForm = document.getElementById('contactForm');
  const successModal = document.getElementById('successModal');
  const closeModalButtons = document.querySelectorAll(
    '.close-modal, .btn-close-modal-btn'
  );

  contactForm?.addEventListener('submit', (e) => {
    e.preventDefault();
    const formData = new FormData(contactForm);
    fetch(contactForm.action, {
      method: 'POST',
      body: formData,
      headers: {
        'X-CSRFToken': getCsrfToken(),
        'X-Requested-With': 'XMLHttpRequest',
      },
      credentials: 'same-origin',
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          successModal.style.display = 'block';
          contactForm.reset();
        } else {
          alert(
            data.message || "Xato yuz berdi. Iltimos, qayta urinib ko'ring."
          );
        }
      })
      .catch((error) => {
        console.error('Formani yuborishda xato:', error);
        alert("Server bilan bog'lanishda xato. Iltimos, qayta urinib ko'ring.");
      });
  });

  closeModalButtons.forEach((button) => {
    button.addEventListener('click', () => {
      successModal.style.display = 'none';
    });
  });
  // form yuklash
  document.addEventListener('DOMContentLoaded', function () {
    const iframe = document.querySelector('.contact-form-wrapper iframe');
    if (iframe) {
      iframe.addEventListener('load', function () {
        console.log('Google Form yuklandi!');
      });
    }
  });
  // Statistika animatsiyasi
  const stats = document.querySelectorAll('.stat-number');
  const animateStats = () => {
    stats.forEach((stat) => {
      const target = parseInt(stat.getAttribute('data-count'));
      let current = 0;
      const increment = target / 100;
      const updateStat = () => {
        if (current < target) {
          current += increment;
          stat.textContent = Math.round(current);
          requestAnimationFrame(updateStat);
        } else {
          stat.textContent = target;
        }
      };
      updateStat();
    });
  };

  // Statistika animatsiyasini faqat ko'rinadigan bo'lsa ishga tushirish
  const statsSection = document.querySelector('.stats-container');
  const observer = new IntersectionObserver(
    (entries) => {
      if (entries[0].isIntersecting) {
        animateStats();
        observer.disconnect();
      }
    },
    { threshold: 0.5 }
  );
  if (statsSection) observer.observe(statsSection);

  // Particles.js konfiguratsiyasi
  if (typeof particlesJS !== 'undefined') {
    particlesJS('hero', {
      particles: {
        number: { value: 80, density: { enable: true, value_area: 800 } },
        color: { value: '#ffffff' },
        shape: { type: 'circle' },
        opacity: { value: 0.5, random: false },
        size: { value: 3, random: true },
        line_linked: {
          enable: true,
          distance: 150,
          color: '#ffffff',
          opacity: 0.4,
          width: 1,
        },
        move: {
          enable: true,
          speed: 6,
          direction: 'none',
          random: false,
          straight: false,
          out_mode: 'out',
          bounce: false,
        },
      },
      interactivity: {
        detect_on: 'canvas',
        events: {
          onhover: { enable: true, mode: 'repulse' },
          onclick: { enable: true, mode: 'push' },
          resize: true,
        },
        modes: {
          repulse: { distance: 100, duration: 0.4 },
          push: { particles_nb: 4 },
        },
      },
      retina_detect: true,
    });
  }
});
