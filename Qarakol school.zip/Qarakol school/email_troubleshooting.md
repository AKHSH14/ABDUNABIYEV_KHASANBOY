# Email Functionality Troubleshooting Guide

This document provides guidance on troubleshooting and testing the email functionality in the QORAKO'L EVOLUTION SCHOOL application.

## Issues Identified

The following issues were identified with the email functionality:

1. **No Email Validation**: The user's email was being retrieved without checking if it was None or empty.
2. **No Error Handling**: The `send_mail()` function was called without any error handling.
3. **No Return Value Checking**: The return value of `send_mail()` was not captured or checked.
4. **No Logging**: There was no logging of the email sending process for debugging purposes.
5. **Unclear Email Settings**: The email settings in `settings.py` were not clearly separated between development and production.

## Changes Made

The following changes were made to address these issues:

1. **Added Email Validation**: Now checking if the user's email is None or empty before attempting to send an email.
2. **Added Error Handling**: Added a try-except block around the `send_mail()` function to catch any exceptions.
3. **Added Return Value Checking**: Now capturing and checking the return value of `send_mail()`.
4. **Added Logging**: Added print statements to log the email sending process for debugging purposes.
5. **Clarified Email Settings**: Reorganized the email settings in `settings.py` to clearly separate development and production settings.
6. **Created Test Scripts**: Created scripts to test the email functionality independently of the application.

## Testing Email Functionality

### Using the Console Backend

The application is currently configured to use the console backend for email, which means emails are printed to the console rather than actually sent. This is useful for development and testing.

To test the email functionality with the console backend:

1. Run the application with `python manage.py runserver`
2. Log in with a user that has an email address
3. Submit the contact form
4. Check the console output for the email content

### Using the Test Script

A test script has been created to verify the email functionality independently of the application:

```bash
python test_email.py
```

This script will:
1. Print the current email settings
2. Attempt to send a test email
3. Print the result or any errors

### Using the Django Shell

You can also test the email functionality directly from the Django shell:

```bash
python manage.py shell
```

Then copy and paste the commands from `test_email_shell.txt` into the shell.

## Switching to SMTP for Production

When you're ready to send real emails in production, you'll need to:

1. Edit `settings.py` and uncomment the SMTP settings
2. Update `EMAIL_HOST_USER` with your actual email address
3. Update `EMAIL_HOST_PASSWORD` with your actual password or app password
4. Comment out the console backend setting

Note: If you're using Gmail with 2-Factor Authentication, you'll need to use an App Password instead of your regular password. You can generate an App Password in your Google Account settings.

## Troubleshooting Common Issues

### Email Not Sending

If emails are not being sent, check the following:

1. **Console Output**: Look for any error messages in the console output.
2. **User Email**: Make sure the user has a valid email address in their profile.
3. **Email Settings**: Verify that the email settings in `settings.py` are correct.
4. **SMTP Credentials**: If using SMTP, verify that the credentials are correct.
5. **Firewall/Network**: If using SMTP, verify that your network allows outgoing connections on the SMTP port.

### Gmail SMTP Issues

If you're using Gmail SMTP and experiencing issues:

1. **App Password**: Make sure you're using an App Password if you have 2-Factor Authentication enabled.
2. **Less Secure Apps**: If you don't have 2-Factor Authentication, you may need to enable "Less Secure Apps" in your Google Account settings.
3. **SMTP Limits**: Gmail has limits on how many emails you can send per day.

## Conclusion

The email functionality has been improved with better error handling, validation, and logging. The application is now configured to use the console backend for development and testing, with clear instructions for switching to SMTP for production.